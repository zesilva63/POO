
public class ImovelInexistenteException extends Exception {

   public ImovelInexistenteException (String msg){
       super(msg);
   }
   
}
