
/**
 * Implementação da Interface Habitavel.
 *
 * @author Grupo 60
 */
public interface Habitavel {



}
