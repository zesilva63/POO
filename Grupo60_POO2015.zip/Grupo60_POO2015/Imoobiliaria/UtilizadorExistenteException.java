public class UtilizadorExistenteException extends Exception { 
    public UtilizadorExistenteException (String msg){
        super(msg);
    }
}
