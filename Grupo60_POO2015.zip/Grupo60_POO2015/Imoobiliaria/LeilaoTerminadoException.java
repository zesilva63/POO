public class LeilaoTerminadoException extends Exception {

   public LeilaoTerminadoException(String msg){
       super(msg);
   }
   
}
